def crear_encuesta(numero):
	numero = numero+".txt"
	archivo = open(numero, "w")

	modulos = input("Ingrese numero de modulos:\n")
	for i in range(modulos):
		archivo.write("Modulo numero ")
		archivo.write(str(i+1))
		archivo.write("\n")
		preguntas = input("Ingrese numero de preguntas:\n")
		for j in range(preguntas):
			pregunta = raw_input("Ingrese pregunta:\n")
			archivo.write(pregunta)
			archivo.write("\n")

	archivo.close()
	return


crear_encuesta("hola")